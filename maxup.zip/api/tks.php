<div class="thankyou-page">
    <!-- <span class="thankyou-page__thanks">Спасибо!</span>
    <img class="thankyou-page__smile" src="/catalog/view/theme/BurnEngine/image/smile/smile.png" alt=""> -->

    <div class="thankyou-page__text"
         style="text-align:center; margin-top:100px; ">
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e9/Check_mark.svg/200px-Check_mark.svg.png"
             alt="">
        <h1>شكرا لطلبكم!</h1>
        <p>
            المشغل سوف يتصل بك
        </p>
    </div>
</div>
<!-- Facebook Pixel Code -->
<img height="1" width="1" src="https://www.facebook.com/tr?id=000&ev=Lead&noscript=1"/> 
<!-- End Facebook Pixel Code -->